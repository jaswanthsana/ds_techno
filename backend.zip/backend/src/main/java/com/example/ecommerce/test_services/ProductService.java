package com.example.ecommerce.test_services;

import com.example.ecommerce.model.Product;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface ProductService {
    List<Product> getAllProducts();
    List<Product> getProductsByCategoryAndPriceOrder(Long categoryId, Sort.Direction priceOrder);
    Product addProduct(Product product);
    Product getProductById(Long productId);
    Product updateProduct(Long productId, Product updatedProduct);
    void deleteProduct(Long productId);
}
