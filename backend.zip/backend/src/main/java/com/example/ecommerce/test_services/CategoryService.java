package com.example.ecommerce.test_services;

import com.example.ecommerce.model.Category;
import java.util.List;

public interface CategoryService {
    Category addCategory(Category category);
    Category updateCategory(Long categoryId, Category updatedCategory);
    void deleteCategory(Long categoryId);
    List<Category> getAllCategories();
    Category getCategoryById(Long categoryId);
}
