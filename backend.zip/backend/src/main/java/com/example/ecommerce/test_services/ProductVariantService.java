package com.example.ecommerce.test_services;

import com.example.ecommerce.model.ProductVariant;
import java.util.List;

public interface ProductVariantService {
    ProductVariant addProductVariant(ProductVariant productVariant);
    ProductVariant getProductVariantById(Long variantId);
    ProductVariant updateProductVariant(Long variantId, ProductVariant updatedVariant);
    void deleteProductVariant(Long variantId);
    List<ProductVariant> getAllProductVariants();
}
