//package com.example.ecommerce.test_services;
//
//import com.example.ecommerce.model.ProductVariant;
//import com.example.ecommerce.repository.ProductVariantRepository;
//import jakarta.persistence.EntityNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//@Service
//public class ProductVariantServiceImpl implements ProductVariantService {
//    private final ProductVariantRepository productVariantRepository;
//
//    @Autowired
//    public ProductVariantServiceImpl(ProductVariantRepository productVariantRepository) {
//        this.productVariantRepository = productVariantRepository;
//    }
//
//    @Override
//    public ProductVariant addProductVariant(ProductVariant productVariant) {
//        return productVariantRepository.save(productVariant);
//    }
//
//    @Override
//    public ProductVariant getProductVariantById(Long variantId) {
//        return productVariantRepository.findById(String.valueOf(variantId))
//                .orElseThrow(() -> new EntityNotFoundException("Product Variant not found"));
//    }
//
//    @Override
//    public ProductVariant updateProductVariant(Long variantId, ProductVariant updatedVariant) {
//        ProductVariant variant = getProductVariantById(variantId);
//
//        variant.setName(updatedVariant.getName());
//        variant.setPrice(updatedVariant.getPrice());
//        // Update other fields...
//
//        return productVariantRepository.save(variant);
//    }
//
//    @Override
//    public void deleteProductVariant(Long variantId) {
//        ProductVariant variant = getProductVariantById(variantId);
//        productVariantRepository.delete(variant);
//    }
//
//    @Override
//    public List<ProductVariant> getAllProductVariants() {
//        return productVariantRepository.findAll();
//    }
//}
//
//
//
//
//
