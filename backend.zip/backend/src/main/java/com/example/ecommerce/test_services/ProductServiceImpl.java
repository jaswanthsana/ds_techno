//package com.example.ecommerce.test_services;
//
//import com.example.ecommerce.model.Product;
//import com.example.ecommerce.repository.ProductRepository;
//import jakarta.persistence.EntityNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Sort;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class ProductServiceImpl implements ProductService {
//    private final ProductRepository productRepository;
//
//    @Autowired
//    public ProductServiceImpl(ProductRepository productRepository) {
//        this.productRepository = productRepository;
//    }
//
//    @Override
//    public List<Product> getAllProducts() {
//        return productRepository.findAll();
//    }
//
//    @Override
//    public Product addProduct(Product product) {
//        return productRepository.save(product);
//    }
//
//    @Override
//    public Product getProductById(Long productId) {
//        return productRepository.findById(productId)
//                .orElseThrow(() -> new EntityNotFoundException("Product not found"));
//    }
//
//    @Override
//    public Product updateProduct(Long productId, Product updatedProduct) {
//        Product product = getProductById(productId);
//
//        product.setName(updatedProduct.getName());
//        product.setDescription(updatedProduct.getDescription());
//        // Update other fields...
//
//        return productRepository.save(product);
//    }
//
//    @Override
//    public void deleteProduct(Long productId) {
//        Product product = getProductById(productId);
//        productRepository.delete(product);
//    }
//
//    @Override
//    public List<Product> getProductsByCategoryAndPriceOrder(Long categoryId, Sort.Direction priceOrder) {
//        Sort sort = Sort.by(priceOrder, "price");
//        return productRepository.findByCategory_Id(categoryId, sort);
//    }
//}
