//package com.example.ecommerce.test_services;
//
//import com.example.ecommerce.model.Category;
//import com.example.ecommerce.repository.CategoryRepository;
//import jakarta.persistence.EntityNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class CategoryServiceImpl implements CategoryService {
//    private final CategoryRepository categoryRepository;
//
//    @Autowired
//    public CategoryServiceImpl(CategoryRepository categoryRepository) {
//        this.categoryRepository = categoryRepository;
//    }
//
//    @Override
//    public Category getCategoryById(Long categoryId) {
//        return categoryRepository.findById(categoryId).orElse(null);
//    }
//
//    @Override
//    public Category addCategory(Category category) {
//        return categoryRepository.save(category);
//    }
//
//    @Override
//    public Category updateCategory(Long categoryId, Category updatedCategory) {
//        Category category = categoryRepository.findById(categoryId)
//                .orElseThrow(() -> new EntityNotFoundException("Category not found"));
//
//        category.setName(updatedCategory.getName());
//        return categoryRepository.save(category);
//    }
//
//    @Override
//    public void deleteCategory(Long categoryId) {
//        Category category = categoryRepository.findById(categoryId)
//                .orElseThrow(() -> new EntityNotFoundException("Category not found"));
//
//        categoryRepository.delete(category);
//    }
//
//    @Override
//    public List<Category> getAllCategories() {
//        return categoryRepository.findAll();
//    }
//}
